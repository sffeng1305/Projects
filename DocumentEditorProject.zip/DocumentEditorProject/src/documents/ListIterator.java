package documents;

public class ListIterator {
	public Link current;
	public Link previous;
	public LinkList ourList;
	
	public ListIterator(LinkList list) {
		ourList = list;
		reset();
	}
	
	public void reset() {
		current = ourList.getFirst();
		previous = null;
	}
	
	public boolean atEnd() {
		return current.next == null;
	}
	
	public void nextLink() {
		previous = current;
		current = current.next;
	}
	
	public Link getCurrent() {
		return current;
	}
	
	public void insertAfter(String data) {
		Link newLink = new Link(data);
		if(ourList.isEmpty()) {
			ourList.setFirst(newLink);
			current = newLink;
		} else {
			newLink.next = current.next;
			current.next = newLink;
			nextLink();
		}
	}
	
	public void checkingInsert(String data) {
		Link newLink = new Link(data);
		Link temp = null;
		if(ourList.isEmpty()) {
			ourList.setFirst(newLink);
			current = newLink;
			ourList.last = current;
		} else {
			temp = ourList.getFirst();
			while(!temp.data.equals(data)) {
				temp = temp.next;
				if(temp == null) {
					newLink.next = current.next;
					current.next = newLink;
					current.iter.insertAfter(data);
					nextLink();
					ourList.last = current;
					current = ourList.last;
					return;
				} 
			}
			current.iter.insertAfter(data);
			current = temp;
		}
	}
	
	public void insertBefore(String data) {
		Link newLink = new Link(data);
		if(previous == null) {//either current is first, or the list empty.
			newLink.next = ourList.getFirst();
			ourList.setFirst(newLink);
			reset();
		} else {
			newLink.next = previous.next;
			previous.next = newLink;
			current = newLink;
		}
	}
	
	public String deleteCurrent() {
		String value = current.data;
		if(previous == null) {
			ourList.setFirst(current.next);
			reset();
		} else {
			previous.next = current.next;
			if(atEnd()) {
				reset();
			} else {
				current = current.next;
			}
		}
		return value;
	}
	
	
	
	
}
