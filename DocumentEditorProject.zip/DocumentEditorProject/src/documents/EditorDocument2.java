package documents;
import java.util.List;

public class EditorDocument2 extends DocumentHelper{
	private int numWords;
	private int numSentences;
	private int numSyllables;
	
	public EditorDocument2(String text) {
		super(text);
		processText();
	}
	
	public List getWordsList() {
		List<String> tokens = getTokens("[a-zA-Z']+");
		return tokens;
	}
	
	private boolean isWord(String tok) {
		return !(tok.indexOf("!") >= 0 || tok.indexOf(".") >= 0 || tok.indexOf("?") >= 0);
	}
	
	private void processText() {
		List<String> tokens = getTokens("[!?.]+|[a-zA-Z]+");
		String lastStr = "";
		for(String str : tokens) {
			if(isWord(str)) {
				numWords++;
				numSyllables += countSyllables(str);
			} else {
				numSentences++;
				lastStr = str;
			}
		}
		if((tokens.lastIndexOf(lastStr) + 1) != tokens.size()) {
			numSentences++;
		}
	}

	public int getNumberOfWords() {
		return numWords;
	}

	public int getNumberOfSyllables() {
		return numSyllables;
	}

	public int getNumberOfSentences() {
		return numSentences;
	}
	
	public double getFleschScore() {
		double score;
		score = 206.835 - (1.015*getNumberOfWords()/getNumberOfSentences()) - 
				(84.6*getNumberOfSyllables()/getNumberOfWords());
		return score;
	}
}
