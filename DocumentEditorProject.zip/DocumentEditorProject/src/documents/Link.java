package documents;


public class Link {
	public String data;
	public Link next;
	public LinkList linkList;
	public ListIterator iter;
	
	public Link(String data) {
		this.data = data;
		linkList = new LinkList();
		iter = linkList.getIterator();
	}
	
	public void displayLink() {
		System.out.println(data + " ");
	}
}
