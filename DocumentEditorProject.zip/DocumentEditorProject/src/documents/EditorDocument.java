package documents;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 
 * An example of implementing the DocumentHelper abstract class. 
 */
public class EditorDocument extends DocumentHelper {
	private String text;
	
	public EditorDocument(String text){
		super(text);
		this.text = text;
	}
	
	public int getNumberOfWords(){ 
	    List<String> tokens = getTokens("[a-zA-Z]+");
	    return tokens.size();
	}
	
	public int getNumberOfSentences() {
	    List<String> tokens = getTokens("[^.!?]+");
	    return tokens.size();
	
	}
	
	public int getNumberOfSyllables() {

		List<String> tokens = getTokens("[a-zA-z]+");  
		int count = 0;   
		for (String token : tokens)  {     
		        count += countSyllables(token);   
		 }   
		return count;
	}
	
	public double getFleschScore(){
		int words = getNumberOfWords();
		int sentences = getNumberOfSentences();
		int syllables = getNumberOfSyllables();
		return 206.835-(1.015*words/sentences)-(84.6*syllables/words);
	}
	
	
	
	
	
}