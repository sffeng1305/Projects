package documents;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class DocumentHelper {

	private String text;
	
	protected DocumentHelper(String text)
	{
		this.text = text;
	}
	
	protected List<String> getTokens(String pattern)
	{
		ArrayList<String> tokens = new ArrayList<String>();
		Pattern tokenSplitter = Pattern.compile(pattern);
		Matcher m = tokenSplitter.matcher(text);
		while (m.find()) {
			tokens.add(m.group());
		}
		return tokens;
	}
	
	protected int countSyllables(String word)
	{
		int num = 0;
		String pattern = "[aeiouyAEIOUY]+";
		Pattern tokenSplitter = Pattern.compile(pattern);
		Matcher m = tokenSplitter.matcher(word);
		String lastToken = "";
		while (m.find()) {
			num++;
			lastToken = m.group();
		}

		if(num > 1 && word.charAt(word.length()-1) == 'e' && lastToken.equals("e")) {
			num--;
		}

		return num;
	}
	
	public abstract int getNumberOfWords();
	public abstract int getNumberOfSentences();
	public abstract int getNumberOfSyllables();
	
	public String getText()
	{
		return this.text;
	}
	
	
}