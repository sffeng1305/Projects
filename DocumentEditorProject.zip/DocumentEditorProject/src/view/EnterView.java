package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EnterView extends MenuBarView{
	
	private Label word;
	private TextField wordTextField;
	private Label length;
	private TextField lengthField;
	private Button enter;
	private Stage stage = new Stage();
	private EnterViewListener listener;
	private MenuItemListener menuItemListener;
	
	
	public EnterView(MenuItemListener menuItemListener) {
		this.menuItemListener = menuItemListener;
		stage.setTitle("Sign In");
		stage.initModality(Modality.APPLICATION_MODAL);
		GridPane grid = new GridPane();
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(10, 10, 10, 10));
		
		word = new Label("Word: ");
		grid.add(word, 0, 0);
		wordTextField = new TextField();
		grid.add(wordTextField, 1, 0);
		
		length = new Label("Length: ");
		grid.add(length, 0, 1);
		lengthField = new TextField();
		grid.add(lengthField, 1, 1);
		
		enter = new Button("Enter");
		enter.setOnAction(e -> {
			String word = wordTextField.getText();
			int length = Integer.parseInt(lengthField.getText());
			if(menuItemListener != null) {
				menuItemListener.menuItemEmitter(7, word, length, null);
			}
			stage.close();
		});
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn.getChildren().add(enter);
		grid.add(hbBtn, 1, 2);
		
		Scene scene = new Scene(grid);
		scene.fillProperty();
		stage.setScene(scene);
		stage.showAndWait();
	}
	
	public void setEnterViewListener(EnterViewListener listener) {
		this.listener = listener;
	}
	
}
