package view;

import java.io.File;
import java.util.EventListener;

import javafx.scene.control.MenuItem;

public interface MenuItemListener extends EventListener{
	
	public void menuItemEmitter(int i, String text, int length, File file);

}
