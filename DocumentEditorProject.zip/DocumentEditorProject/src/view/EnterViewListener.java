package view;

import java.util.EventListener;

public interface EnterViewListener extends EventListener{

	public void emitter(String word, int length);
}
