package view;

import java.util.EventObject;

public class GenericEventObject extends EventObject{
	private String text;
	private Object source;

	public GenericEventObject(Object source, String text) {
		super(source);
		this.source = source;
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public Object getSource() {
		return source;
	}
	
	

}
