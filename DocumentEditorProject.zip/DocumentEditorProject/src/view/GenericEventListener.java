package view;

import java.util.EventListener;

public interface GenericEventListener extends EventListener{
	
	public void stringEmitter(GenericEventObject ev);
	
}
