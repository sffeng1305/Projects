package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DisplayMessageBox {
	
	public static void display(String message) {
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setMinWidth(300);
		Label label = new Label(message);
		Button cancel = new Button("Cancel");
		cancel.setOnAction(e -> {
			stage.close();
		});
		
		VBox vbox = new VBox(10);
		vbox.setPadding(new Insets(10, 10, 10, 10));
		vbox.getChildren().addAll(label, cancel);
		vbox.setAlignment(Pos.CENTER);
		Scene scene = new Scene(vbox);
		stage.setScene(scene);
		stage.showAndWait();
	}
}
