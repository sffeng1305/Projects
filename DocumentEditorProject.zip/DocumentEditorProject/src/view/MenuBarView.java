package view;

import java.io.File;
import java.util.Scanner;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class MenuBarView {
	protected MenuItemListener menuItemListener;
	private Stage stage;
	private View view;
	private MenuItem openItem;
	private String word;
	private int length;
	
	public MenuBarView() {}
	
	public MenuBarView(MenuBar menuBar, Stage stage, View view) {
		this.stage = stage;
		this.view = view;
		Menu fileMenu = new Menu("File");
		MenuItem newItem = new MenuItem("New");
		openItem = new MenuItem("Open");
		MenuItem saveItem = new MenuItem("Save");
		MenuItem closeItem = new MenuItem("Close");
		MenuItem exitItem = new MenuItem("Exit");
		
		openItem.setOnAction(e -> {
			setOpenItem();
		});
		newItem.setOnAction(e -> {
			setNewItem();
		});
		exitItem.setOnAction(e -> {
			e.consume();
			closeProgram();
		});
		saveItem.setOnAction(e -> {
			setSaveItem();
		});
		closeItem.setOnAction(e -> {
			view.clear();
		});
		
		
		fileMenu.getItems().addAll(newItem, openItem, saveItem, closeItem, exitItem);
		
		Menu editMenu = new Menu("Edit");
		MenuItem wordCount = new MenuItem("Word Count");
		MenuItem sentenceCount = new MenuItem("Sentence Count");
		MenuItem fleshScore = new MenuItem("Flesh Score");
		MenuItem test = new MenuItem("Performance Test");
		MenuItem study = new MenuItem("Study");
		MenuItem autocomplete = new MenuItem("Autocomplete");
		
		wordCount.setOnAction(e -> {
			if(menuItemListener != null) {
				menuItemListener.menuItemEmitter(0, null, -1, null);
			}
		});
		
		sentenceCount.setOnAction(e -> {
			if(menuItemListener != null) {
				menuItemListener.menuItemEmitter(1, null, -1, null);
			}
		});
		
		fleshScore.setOnAction(e -> {
			if(menuItemListener != null) {
				menuItemListener.menuItemEmitter(2, null, -1, null);
			}
		});
		
		test.setOnAction(e -> {
			if(menuItemListener != null) {
				menuItemListener.menuItemEmitter(5, null, -1, null);
			}
		});
		
		study.setOnAction(e -> {
			if(menuItemListener != null) {
				menuItemListener.menuItemEmitter(6, null, -1, null);
			}
		});
		
		autocomplete.setOnAction(e -> {
			EnterView enterView = new EnterView(menuItemListener);
		});
		
		
		editMenu.getItems().addAll(wordCount, sentenceCount, fleshScore, test, study, autocomplete);
		menuBar.getMenus().addAll(fileMenu, editMenu);
	}
	
	private void setSaveItem() {
		 FileChooser fileChooser = new FileChooser();
         FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
         fileChooser.getExtensionFilters().add(extFilter);
         File file = fileChooser.showSaveDialog(stage);
         if(file != null){
        	 if(menuItemListener != null) {
 				menuItemListener.menuItemEmitter(4, null, -1, file);
 			}
         }
	}
	
	private void setNewItem() {
		view.clear();
	}
	
	private void setOpenItem() {
		FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(extFilter);
        File file = fileChooser.showOpenDialog(stage);
        try {
			Scanner input = new Scanner(file);
			String text = input.useDelimiter("\\A").next();
			if(menuItemListener != null) {
				menuItemListener.menuItemEmitter(3, text, -1, null);
			}
		} catch (Exception e1) {
		}
	}
	
	public void setMenuItemListener(MenuItemListener listener) {
		this.menuItemListener = listener;
	}
	
	private void closeProgram(){
		Boolean result = ConfirmBox.display("Title", "Are you sure you want to exit");
		if(result == true){
			stage.close();
		}
	}
	
	public void setWord(String s) {
		this.word = s;
	}
	
	public void setLength(int l) {
		this.length = l;
	}
}
