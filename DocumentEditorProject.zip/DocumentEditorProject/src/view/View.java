package view;

import documents.EditorDocument;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class View {
	private final TextArea textArea;
	private final MenuBar menuBar;
	private final MenuBarView mbv;
	private HBox hbox;
	private Label wordLabel;
	private Label sentenceLabel;
	private Label syllablesLabel;
	private GenericEventListener listener;
	private Stage stage;
	
	public View(Stage stage) {
		this.stage = stage;
		stage.setTitle("Document Editor");
		stage.setOnCloseRequest(e -> {
			e.consume();
			closeProgram();
		});
		menuBar = new MenuBar();
		mbv = new MenuBarView(menuBar, stage, this);
		textArea = new TextArea();
		textArea.setWrapText(true);
		textArea.setPrefSize(600, 400);
		textArea.textProperty().addListener(new ChangeListener<String>() {
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				GenericEventObject ev = new GenericEventObject(this, newValue);
				if(listener != null) {
					listener.stringEmitter(ev);
				}
			}
		});
		
		hbox = new HBox();
		hbox.setPadding(new Insets(5, 5, 5, 5));
		hbox.setSpacing(35);
		wordLabel = new Label("Word Count: 0");
		sentenceLabel = new Label("Sentence Count: 0");
		syllablesLabel = new Label("Syllables count: 0");
		hbox.getChildren().addAll(wordLabel, sentenceLabel, syllablesLabel);
		
		BorderPane bp = new BorderPane();
		bp.setTop(menuBar);
		bp.setCenter(textArea);
		bp.setBottom(hbox);
		
		Scene scene = new Scene(bp);
		scene.fillProperty();
		stage.setScene(scene);
		stage.show();
	}
	
	public void setListener(GenericEventListener listener) {
		this.listener = listener;
	}
	
	public void setWordLabel(String words) {
		wordLabel.setText(words);
	}
	
	public void setSentencesLabel(String sentencs) {
		sentenceLabel.setText(sentencs);
	}
	
	public void setSyllablesLabel(String syllables) {
		syllablesLabel.setText(syllables);
	}
	
	public void setText(String text) {
		textArea.appendText(text);
	}
	
	public MenuBarView getMenuBarView() {
		return mbv;
	}
	
	public void setEditable(boolean value) {
		textArea.setEditable(value);
	}
	
	public void clear() {
		textArea.clear();
	}
	
	private void closeProgram(){
		Boolean result = ConfirmBox.display("Title", "Are you sure you want to exit");
		if(result == true){
			stage.close();
		}
	}
	
}
