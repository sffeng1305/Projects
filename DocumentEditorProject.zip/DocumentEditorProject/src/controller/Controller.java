package controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import documents.EditorDocument;
import documents.EditorDocument2;
import documents.Link;
import documents.LinkList;
import documents.ListIterator;
import view.DisplayMessageBox;
import view.EnterView;
import view.GenericEventListener;
import view.GenericEventObject;
import view.MenuItemListener;
import view.View;

public class Controller {
	private EditorDocument2 ed;
	private int words;
	private int sentences;
	private double fleshScore;
	private int syllables;
	private String currentText;
	private LinkList linkList = new LinkList();
	private ListIterator iter = linkList.getIterator();
	private ArrayList<String> list = null;
	
	public Controller(View view) {
		view.setListener(new GenericEventListener() {

			public void stringEmitter(GenericEventObject ev) {
				currentText = ev.getText();
				ed = new EditorDocument2(currentText);
				words = ed.getNumberOfWords();
				sentences = ed.getNumberOfSentences();
				syllables = ed.getNumberOfSyllables();
				view.setWordLabel("Word Count: " + words);
				view.setSentencesLabel("Sentence Count: " + sentences);
				view.setSyllablesLabel("Syllables count: " + syllables);
			}
			
		});
		
		view.getMenuBarView().setMenuItemListener(new MenuItemListener() {

			@SuppressWarnings("unchecked")
			public void menuItemEmitter(int i, String text, int length, File file) {
				switch(i){
				case 0:
					DisplayMessageBox.display("Total number of words is " + words+ ".");
					break;
				case 1:
					DisplayMessageBox.display("Total number of sentences is " + sentences + ".");
					break;
				case 2:
					if(words == 0 || sentences == 0) {
						return;
					}
					double fleshScore = ed.getFleschScore();
					Double fl = Double.parseDouble(new DecimalFormat("#.##").format(fleshScore));
					String result = getFleshScoreResult(fl);
					DisplayMessageBox.display("Flesh score is " + fl + 
							". School level regrading to the flesh score is: " + result + ".");
					break;
				case 3:
					view.setText(text);
					break;
				case 4:
					FileWriter fileWriter = null;
		            try {
						fileWriter = new FileWriter(file);
						fileWriter.write(currentText);
			            fileWriter.flush();
			            fileWriter.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
		            break;
				case 5:
					if(words == 0 && sentences == 0 && syllables == 0) {
						return;
					}
					EditorDocument2 ed2 = new EditorDocument2(currentText);
					long lStartTime = System.nanoTime();
					int w = ed2.getNumberOfWords();
					int s = ed2.getNumberOfSentences();
					int syl = ed2.getNumberOfSyllables();
					long lEndTime = System.nanoTime();
					long difference = lEndTime - lStartTime;
					String str1 = "Elapsed nano second for one loop is: " + (difference);
					
					EditorDocument ed1 = new EditorDocument(currentText);
					long lStartTime2 = System.nanoTime();
					int w2 = ed1.getNumberOfWords();
					int s2 = ed1.getNumberOfSentences();
					int sy2l = ed1.getNumberOfSyllables();
					long lEndTime2 = System.nanoTime();
					long difference2 = lEndTime2 - lStartTime2;
					String str2 = "Elapsed nano second for separate loops is: " + (difference2);
					DisplayMessageBox.display(str1 + "\n" + str2);
					break;
				case 6:
					list = (ArrayList<String>) ed.getWordsList();
					for(String word: list){
						String lower = null;
						if(!word.equals("I")) {
							lower = word.toLowerCase();
							iter.checkingInsert(lower);
						} else {
							iter.checkingInsert(word);
						}
					}
					DisplayMessageBox.display("Study completed...");;
					break;
				case 7:
					if(list == null) {
						return;
					}
					view.clear();
					String word = text;
					view.setText(word + " ");
					int count = 0;
					while (count != length-1) {
						iter.reset();
						Link aLink = linkList.getFirst();
						while (!iter.atEnd()) {
							if (aLink.data.equals(word) && aLink.iter.current != null) {
								aLink.iter.reset();
								int r = (int) (Math.random() * (aLink.linkList.getSize() - 0)) + 0;
								for(int k = 0; k < r; k++) {
									aLink.iter.nextLink();
								}
								word = aLink.iter.current.data;
								view.setText(word + " ");
								break;
							}
							iter.nextLink();
							aLink = iter.getCurrent();
						} 
						count++;
					}
					break;
				}
			}
		});
	
	}
	
	private String getFleshScoreResult(double fleshScore) {
		if(fleshScore >= 90 && fleshScore <=100) {
			return "5th grade";
		} else if(fleshScore >= 80 && fleshScore < 90) {
			return "6th grade";
		} else if(fleshScore >= 70 && fleshScore < 80) {
			return "7th grade";
		} else if(fleshScore >= 60 && fleshScore < 70) {
			return "8th & 9th grade";
		} else if(fleshScore >= 50 && fleshScore < 60) {
			return "10th to 12th grade";
		} else if(fleshScore >= 30 && fleshScore < 50) {
			return "college ";
		} else if(fleshScore >= 0 && fleshScore < 30) {
			return "college graduate";
		} else {
			return null;
		}
	}
	
}
