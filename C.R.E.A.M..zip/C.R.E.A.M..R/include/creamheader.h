#ifndef CREAMHEADER_H
#define CREAMHEADER_H

typedef struct args_t {
    int NUM_WORKERS;
    char *PORT_NUMBER;
    int MAX_ENTRIES;
} args_t;

void displayHelp();
void map_free_function(map_key_t key, map_val_t val);
args_t *parse_args(int argc, char **argv);
void *thread(void *vargp);
void handle_request(int connfd, request_header_t request_header);
void handle_put(int connfd, request_header_t request_header);
void handle_get(int connfd, request_header_t request_header);
void handle_evict(int connfd, request_header_t request_header);
void handle_clear(int connfd);
void handle_notSupport(int connfd);

#endif