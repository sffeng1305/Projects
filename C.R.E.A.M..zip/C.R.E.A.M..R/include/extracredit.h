/*
 * You may modify any fields in the structs below.
 * **DO NOT** change the names of the structs or the function prototypes.
 */

#ifndef EXTRACREDIT_H
#define EXTRACREDIT_H

#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "const.h"
#include <time.h>
//hashmap
typedef struct map_key_t {
    void *key_base;
    size_t key_len;
} map_key_t;
typedef struct map_val_t {
    void *val_base;
    size_t val_len;
} map_val_t;
typedef uint32_t (*hash_func_f)(map_key_t);
typedef void (*destructor_f)(map_key_t, map_val_t);
typedef struct map_node_t {
    map_key_t key;
    map_val_t val;
    bool tombstone;
    time_t begin;
} map_node_t;
typedef struct hashmap_t {
    uint32_t capacity;
    uint32_t size;
    map_node_t *nodes;
    hash_func_f hash_function;
    destructor_f destroy_function;
    int num_readers;
    pthread_mutex_t write_lock;
    pthread_mutex_t fields_lock;
    bool invalid;
} hashmap_t;
hashmap_t *create_map(uint32_t capacity, hash_func_f hash_function, destructor_f destroy_function);
bool put(hashmap_t *self, map_key_t key, map_val_t val, bool force);
map_val_t get(hashmap_t *self, map_key_t key);
map_node_t delete(hashmap_t *self, map_key_t key);
bool clear_map(hashmap_t *self);
bool invalidate_map(hashmap_t *self);


//link list
typedef struct linklist_node {
    int index;
    struct linklist_node *next;
} linklist_node;

typedef struct linklist {
    linklist_node *front, *rear;
} linklist;

void create_linklist();
void push(linklist *self, int index);
void deleteIndex(linklist *self, int index);
int getIndex(linklist *self);
void switchNode(linklist *self);
#endif
