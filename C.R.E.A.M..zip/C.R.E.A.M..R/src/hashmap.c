#include "utils.h"
#include <errno.h>
#include <stdio.h>
#include "debug.h"
#include <string.h>

bool isNodeEmpty(map_node_t *node);
bool compareKey(void* keybase1, void* keybase2, int keylength1, int keylength2);
#define MAP_KEY(base, len) (map_key_t) {.key_base = base, .key_len = len}
#define MAP_VAL(base, len) (map_val_t) {.val_base = base, .val_len = len}
#define MAP_NODE(key_arg, val_arg, tombstone_arg) (map_node_t) {.key = key_arg, .val = val_arg, .tombstone = tombstone_arg}

hashmap_t *create_map(uint32_t capacity, hash_func_f hash_function, destructor_f destroy_function) {
    if(hash_function == NULL || destroy_function == NULL) {
        errno = EINVAL;
        return NULL;
    }
    hashmap_t *hashmap = (hashmap_t*)calloc(1, sizeof(hashmap_t));
    if(hashmap == NULL) {
        return NULL;
    }
    map_node_t *node = (map_node_t*)calloc(capacity, sizeof(map_node_t));
    if(node == NULL) {
        return NULL;
    }
    hashmap->nodes = node;
    hashmap->capacity = capacity;
    hashmap->hash_function = hash_function;
    hashmap->destroy_function = destroy_function;
    int ret = pthread_mutex_init(&(hashmap->write_lock), 0);
    if(ret != 0) {
        return NULL;
    }
    int ret2 = pthread_mutex_init(&(hashmap->fields_lock), 0);
    if(ret2 != 0) {
        return NULL;
    }
    return hashmap;
}

bool put(hashmap_t *self, map_key_t key, map_val_t val, bool force) {
    if(self==NULL){
        errno = EINVAL;
        return false;
    }

    pthread_mutex_lock(&self->write_lock);
    if(self->invalid == true
        || key.key_len==0 || key.key_base==NULL
        || val.val_len==0 || val.val_base==NULL) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->write_lock);
        return false;
    }
    pthread_mutex_unlock(&self->write_lock);

    if(self->size == self->capacity && force == true) {
        pthread_mutex_lock(&self->write_lock);
        int index = get_index(self, key);
        map_node_t *nodes = self->nodes;
        self->destroy_function((nodes+index)->key, (nodes+index)->val);
        (nodes+index)->key = key;
        (nodes+index)->val = val;
        pthread_mutex_unlock(&self->write_lock);
        return true;
    }else if(self->size == self->capacity && force == false) {
        errno = ENOMEM;
        return false;
    }

    hash_func_f hash_function = self->hash_function;
    map_node_t *nodes = self->nodes;
    int index = hash_function(key)%self->capacity;
    pthread_mutex_lock(&self->write_lock);
    if((nodes+index)->key.key_base == NULL && (nodes+index)->val.val_base == NULL) {
        (nodes+index)->key = key;
        (nodes+index)->val = val;
        debug("The value in the map %s", (char*)((nodes+index)->val.val_base));
        pthread_mutex_lock(&self->fields_lock);
        self->size = self->size + 1;
        pthread_mutex_unlock(&self->fields_lock);
        pthread_mutex_unlock(&self->write_lock);
        return true;
    }else if((nodes+index)->tombstone == true){
        (nodes+index)->tombstone = false;
        (nodes+index)->key = key;
        (nodes+index)->val = val;
        pthread_mutex_unlock(&self->write_lock);
        return true;
    }else if( compareKey((nodes+index)->key.key_base, key.key_base, (nodes+index)->key.key_len, key.key_len) == true
                && (nodes+index)->tombstone != true) {
         self->destroy_function((nodes+index)->key, (nodes+index)->val);
         (nodes+index)->key = key;
        (nodes+index)->val = val;
        pthread_mutex_unlock(&self->write_lock);
        return true;
    }else {//linear probing
        int end = self->capacity;
        for(int i = index+1; i < end; i++){
            if(isNodeEmpty(nodes+i) == true) {
                (nodes+i)->key = key;
                (nodes+i)->val = val;
                pthread_mutex_lock(&self->fields_lock);
                self->size = self->size + 1;
                pthread_mutex_unlock(&self->fields_lock);
                pthread_mutex_unlock(&self->write_lock);
                return true;
            }
        }
        for(int i = 0; i < index; i++) {
            if(isNodeEmpty(nodes+i) == true) {
                (nodes+i)->key = key;
                (nodes+i)->val = val;
                pthread_mutex_lock(&self->fields_lock);
                self->size = self->size + 1;
                pthread_mutex_unlock(&self->fields_lock);
                pthread_mutex_unlock(&self->write_lock);
                return true;
            }
        }

    }
    pthread_mutex_unlock(&self->write_lock);
    return false;
}

map_val_t get(hashmap_t *self, map_key_t key) {
    if(self==NULL){
        errno = EINVAL;
        return MAP_VAL(NULL, 0);
    }

    pthread_mutex_lock(&self->write_lock);
    if(self->invalid == true || key.key_len==0 || key.key_base==NULL) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->write_lock);
        return MAP_VAL(NULL, 0);
    }
    pthread_mutex_unlock(&self->write_lock);

    pthread_mutex_lock(&self->fields_lock);
    self->num_readers = self->num_readers + 1;
    if(self->num_readers == 1) {
        pthread_mutex_lock(&self->write_lock);
    }
    pthread_mutex_unlock(&self->fields_lock);


    hash_func_f hash_function = self->hash_function;

    map_node_t *nodes = self->nodes;
    int index = hash_function(key)%self->capacity;
    if(compareKey((nodes+index)->key.key_base, key.key_base, (nodes+index)->key.key_len, key.key_len) == true
        && (nodes+index)->tombstone != true) {
        pthread_mutex_lock(&self->fields_lock);
        self->num_readers = self->num_readers - 1;
        if(self->num_readers == 0) {
            pthread_mutex_unlock(&self->write_lock);
        }
        pthread_mutex_unlock(&self->fields_lock);
        return (nodes+index)->val;
    }else {
        int end = self->capacity;
        for(int i = index+1; i < end; i++) {
            if((nodes+i)->key.key_base == NULL && (nodes+i)->val.val_base == NULL) {
                pthread_mutex_lock(&self->fields_lock);
                self->num_readers = self->num_readers - 1;
                if(self->num_readers == 0) {
                    pthread_mutex_unlock(&self->write_lock);
                }
                pthread_mutex_unlock(&self->fields_lock);
                return MAP_VAL(NULL, 0);
            }else if(compareKey((nodes+i)->key.key_base, key.key_base, (nodes+i)->key.key_len, key.key_len) == true
                        && (nodes+i)->tombstone != true) {
                pthread_mutex_lock(&self->fields_lock);
                self->num_readers = self->num_readers - 1;
                if(self->num_readers == 0) {
                    pthread_mutex_unlock(&self->write_lock);
                }
                pthread_mutex_unlock(&self->fields_lock);
                return (nodes+i)->val;
            }
        }

        for(int i = 0; i < index; i++) {
            if((nodes+i)->key.key_base == NULL && (nodes+i)->val.val_base == NULL) {
                pthread_mutex_lock(&self->fields_lock);
                self->num_readers = self->num_readers - 1;
                if(self->num_readers == 0) {
                    pthread_mutex_unlock(&self->write_lock);
                }
                pthread_mutex_unlock(&self->fields_lock);
                return MAP_VAL(NULL, 0);
            }else if(compareKey((nodes+i)->key.key_base, key.key_base, (nodes+i)->key.key_len, key.key_len)
                        && (nodes+i)->tombstone != true) {
                pthread_mutex_lock(&self->fields_lock);
                self->num_readers = self->num_readers - 1;
                if(self->num_readers == 0) {
                    pthread_mutex_unlock(&self->write_lock);
                }
                pthread_mutex_unlock(&self->fields_lock);
                return (nodes+i)->val;
            }
        }
    }
    pthread_mutex_lock(&self->fields_lock);
    self->num_readers = self->num_readers - 1;
    if(self->num_readers == 0) {
        pthread_mutex_unlock(&self->write_lock);
    }
    pthread_mutex_unlock(&self->fields_lock);
    return MAP_VAL(NULL, 0);
}

map_node_t delete(hashmap_t *self, map_key_t key) {
    if(self==NULL){
        errno = EINVAL;
        return MAP_NODE(MAP_KEY(NULL, 0), MAP_VAL(NULL, 0), false);
    }

    hash_func_f hash_function = self->hash_function;
    map_node_t *nodes = self->nodes;
    int index = hash_function(key)%self->capacity;
    pthread_mutex_lock(&self->write_lock);

    if(self->invalid == true || key.key_len==0 || key.key_base==NULL) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->write_lock);
        return MAP_NODE(MAP_KEY(NULL, 0), MAP_VAL(NULL, 0), false);
    }


    if(compareKey((nodes+index)->key.key_base, key.key_base, (nodes+index)->key.key_len, key.key_len) == true ) {
        (nodes+index)->tombstone = true;
        pthread_mutex_lock(&self->fields_lock);
        self->size = self->size - 1;
        pthread_mutex_unlock(&self->fields_lock);
        pthread_mutex_unlock(&self->write_lock);
        return *(nodes+index);
    }else {
        int end = self->capacity;
        for(int i = index+1; i < end; i++) {
            if((nodes+i)->key.key_base == NULL && (nodes+i)->val.val_base == NULL) {
                pthread_mutex_unlock(&self->write_lock);
                return MAP_NODE(MAP_KEY(NULL, 0), MAP_VAL(NULL, 0), false);
            }else if(compareKey((nodes+i)->key.key_base, key.key_base, (nodes+i)->key.key_len, key.key_len)) {
                (nodes+i)->tombstone = true;
                pthread_mutex_lock(&self->fields_lock);
                self->size = self->size - 1;
                pthread_mutex_unlock(&self->fields_lock);
                pthread_mutex_unlock(&self->write_lock);
                return *(nodes+i);
            }
        }

        for(int i = 0; i < index; i++) {
            if((nodes+i)->key.key_base == NULL && (nodes+i)->val.val_base == NULL) {
                pthread_mutex_unlock(&self->write_lock);
                return MAP_NODE(MAP_KEY(NULL, 0), MAP_VAL(NULL, 0), false);
            }else if(compareKey((nodes+i)->key.key_base, key.key_base, (nodes+i)->key.key_len, key.key_len)) {
                (nodes+i)->tombstone = true;
                pthread_mutex_lock(&self->fields_lock);
                self->size = self->size - 1;
                pthread_mutex_unlock(&self->fields_lock);
                pthread_mutex_unlock(&self->write_lock);
                return *(nodes+i);
            }
        }
    }
    pthread_mutex_unlock(&self->write_lock);
    return MAP_NODE(MAP_KEY(NULL, 0), MAP_VAL(NULL, 0), false);
}

bool clear_map(hashmap_t *self) {
    if(self==NULL) {
        errno = EINVAL;
        return false;
    }
    pthread_mutex_lock(&self->write_lock);
    if(self->invalid == true) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->write_lock);
        return false;
    }

    destructor_f destroy_function = self->destroy_function;
    map_node_t *nodes = self->nodes;
    self->size = 0;
    for(int i = 0; i < self->capacity; i++) {
        if(isNodeEmpty(nodes+i) == false) {
            destroy_function((nodes+i)->key, (nodes+i)->val);
            (nodes+i)->key.key_base = NULL;
            (nodes+i)->key.key_len = 0;
            (nodes+i)->val.val_base = NULL;
            (nodes+i)->val.val_len = 0;
        }

    }
    pthread_mutex_unlock(&self->write_lock);
	return true;
}

bool invalidate_map(hashmap_t *self) {
    if(self==NULL) {
        errno = EINVAL;
        return false;
    }


    pthread_mutex_lock(&self->write_lock);
    if(self->invalid == true) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->write_lock);
        return false;
    }
    destructor_f destroy_function = self->destroy_function;
    map_node_t *nodes = self->nodes;
    for(int i = 0; i < self->capacity; i++) {
        if(isNodeEmpty(nodes+i) == false) {
            destroy_function((nodes+i)->key, (nodes+i)->val);
            (nodes+i)->key.key_base = NULL;
            (nodes+i)->key.key_len = 0;
            (nodes+i)->val.val_base = NULL;
            (nodes+i)->val.val_len = 0;
        }
    }
    free(nodes);
    self->invalid = true;
    pthread_mutex_unlock(&self->write_lock);
    return true;
}

bool isNodeEmpty(map_node_t *node) {
    if(node->key.key_base==NULL && node->val.val_base == NULL) {
        return true;
    }else if(node->tombstone == true) {
        return true;
    }else {
        return false;
    }
}

bool compareKey(void* keybase1, void* keybase2, int keylength1, int keylength2) {
    if(keybase1 == NULL || keybase2 == NULL) {
        return false;
    }

    if(keylength1 == keylength2) {
        size_t n = keylength1;
        if(memcmp(keybase1, keybase2, n) == 0){
            return true;
        }
    }
    return false;
}
