#include "queue.h"
#include <stdlib.h>
#include <semaphore.h>
#include <errno.h>
#include <stdio.h>
#include "debug.h"
pthread_cond_t ready_cond = PTHREAD_COND_INITIALIZER;

queue_t *create_queue(void) {
    queue_t *queue = (queue_t*)calloc(1, sizeof(queue_t));
    if(queue == NULL) {
        return NULL;
    }
    queue->front = queue->rear = 0;
    int ret = pthread_mutex_init(&(queue->lock), 0);
    if(ret != 0) {
        return NULL;
    }
    sem_init(&(queue->items), 0, 0);
    return queue;
}

bool invalidate_queue(queue_t *self, item_destructor_f destroy_function) {
    if(self == NULL || destroy_function == NULL) {
        errno = EINVAL;
        return false;
    }
    pthread_mutex_lock(&self->lock);
    if(self->invalid == true) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->lock);
        return false;
    }
    queue_node_t *node = self->front;
    while(node != NULL) {
        queue_node_t *temp = node->next;
        destroy_function(node -> item);
        debug("%d\n", *(int *)(node->item));
        free(node);
        node = temp;
    }


    self->invalid = true;
    pthread_mutex_unlock(&self->lock);
    return true;
}

bool enqueue(queue_t *self, void *item) {
    if(self == NULL) {
        errno = EINVAL;
        return false;
    }
    pthread_mutex_lock(&self->lock);
    if(self->invalid == true) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->lock);
        return false;
    }
    queue_node_t *node = (queue_node_t*)calloc(1, sizeof(queue_node_t));
    node->item = item; // insert item
    node->next = NULL;

    if(self->rear == NULL && self->front == NULL) {
        self->front = node;
        self->rear = node;
        //pthread_cond_signal(&ready_cond);
        pthread_mutex_unlock(&self->lock);
        sem_post(&self->items);
        return true;
    }else {
        self->rear->next = node;
        self->rear = node;
    }
    //pthread_cond_signal(&ready_cond);
    pthread_mutex_unlock(&self->lock);
    sem_post(&self->items);
    return true;
}

void *dequeue(queue_t *self) {
    if(self == NULL) {
        errno = EINVAL;
        return NULL;
    }

    pthread_mutex_lock(&self->lock);
    if(self->invalid == true) {
        errno = EINVAL;
        pthread_mutex_unlock(&self->lock);
        return false;
    }
    pthread_mutex_unlock(&self->lock);


     /*pthread_mutex_lock(&self->lock);
    if(self->front == NULL) {
        pthread_cond_wait(&ready_cond, &self->lock);
    }
    pthread_mutex_unlock(&self->lock);*/

    sem_wait(&self->items);
    pthread_mutex_lock(&self->lock);
    void *item;
    queue_node_t *temp = self->front;
    item = self->front->item;
    self->front = self->front->next;
    free(temp);
    if(self->front == NULL) {
        self->rear = NULL;
    }
    pthread_mutex_unlock(&self->lock);
    return item;
}
