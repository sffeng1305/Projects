#include "cream.h"
#include "utils.h"
#include <stdio.h>
#include "queue.h"
#include "creamheader.h"
#include "string.h"
#include "csapp.h"
#include "debug.h"
int listenfd;
int *connfd;
socklen_t clientlen;
struct sockaddr_storage clientaddr;
pthread_t tid;
queue_t *queue;
hashmap_t *hashmap;

int main(int argc, char *argv[]) {
    signal(SIGPIPE, SIG_IGN);
    if(strcmp("-h", argv[1]) == 0) {
        displayHelp();
        exit(EXIT_SUCCESS);
    }
    args_t *args;
    if (!(args = parse_args(argc, argv))) {
        app_error("invalid number of arguments.");
    }

    listenfd = Open_listenfd(args->PORT_NUMBER);
    queue = create_queue();
    hashmap = create_map(args->MAX_ENTRIES, jenkins_one_at_a_time_hash, map_free_function);

    //spawn worker threads
    for (int i = 0; i < args->NUM_WORKERS; i++){
        Pthread_create(&tid, NULL, thread, NULL);
    }/* Create worker threads */
    free(args->PORT_NUMBER);
    free(args);

    while(1) {
        clientlen = sizeof(struct sockaddr_storage);
        connfd = calloc(1, sizeof(int));
        *connfd = Accept(listenfd, (SA *) &clientaddr, &clientlen);
        enqueue(queue, connfd);
    }

    exit(0);
}

void map_free_function(map_key_t key, map_val_t val) {
    free(key.key_base);
    free(val.val_base);
}

void displayHelp() {
    printf("-h                 Displays this help menu and returns EXIT_SUCCESS.\n");
    printf("NUM_WORKERS        The number of worker threads used to service requests.\n");
    printf("PORT_NUMBER        Port number to listen on for incoming connections.\n");
    printf("MAX_ENTRIES        The maximum number of entries that can be stored in `cream`'s underlying data store.\n");
}

args_t *parse_args(int argc, char **argv) {
    if (argc != 4) {
        return NULL;
    }

    args_t *args = malloc(sizeof(args_t));
    args->NUM_WORKERS = atoi(argv[1]);
    args->PORT_NUMBER = strdup(argv[2]);
    args->MAX_ENTRIES = atoi(argv[3]);

    return args;
}

void *thread(void *vargp) {
    Pthread_detach(pthread_self());

    while(1) {
        int *connfd = (int*)dequeue(queue);
        request_header_t request_header;
        int n = rio_readn(*connfd, &request_header, sizeof(request_header));
        if(n > 0) {
            handle_request(*connfd, request_header);
        }

        Close(*connfd);
        free(connfd);
    }
}

void handle_request(int connfd, request_header_t request_header) {
    uint8_t request_code = request_header.request_code;
    debug("Request code, %u", request_code);
    switch(request_code){
        case 1:
            debug("handling PUT request");
            handle_put(connfd, request_header);
            break;

        case 2:
            debug("handling GET request");
            handle_get(connfd, request_header);
            break;

        case 4:
            debug("handling EVICT request");
            handle_evict(connfd, request_header);
            break;

        case 8:
            debug("handling CLEAR request");
            handle_clear(connfd);
            break;
        default:
            handle_notSupport(connfd);
            break;
    }
}

void handle_notSupport(int connfd) {
    response_header_t response_header = {UNSUPPORTED, 0};
    Rio_writen(connfd, &response_header, sizeof(response_header));
}

void handle_put(int connfd, request_header_t request_header){
    uint32_t key_size = request_header.key_size;
    uint32_t value_size = request_header.value_size;
    if(key_size < MIN_KEY_SIZE || key_size > MAX_KEY_SIZE) {
        response_header_t response_header = {BAD_REQUEST, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
        return;
    }

    if(value_size < MIN_VALUE_SIZE || value_size > MAX_VALUE_SIZE) {
        response_header_t response_header = {BAD_REQUEST, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
        return;
    }
    char *key = calloc(1, request_header.key_size);
    char *value = calloc(1, request_header.value_size);
    Rio_readn(connfd, key, request_header.key_size);
    Rio_readn(connfd, value, request_header.value_size);

    map_key_t mapkey = {key, strlen(key)};
    map_val_t mapval = {value, strlen(value)};
    if(put(hashmap, mapkey, mapval, true) == true) {
        response_header_t response_header = {OK, strlen(value)};
        Rio_writen(connfd, &response_header, sizeof(response_header));
    }else {
        response_header_t response_header = {BAD_REQUEST, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
    }
}

void handle_get(int connfd, request_header_t request_header) {
    uint32_t key_size = request_header.key_size;
    if(key_size < MIN_KEY_SIZE || key_size > MAX_KEY_SIZE) {
        response_header_t response_header = {BAD_REQUEST, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
        return;
    }
    char *key = calloc(1, request_header.key_size);
    Rio_readn(connfd, key, request_header.key_size);
    map_key_t mapkey = {key, strlen(key)};
    map_val_t retVal = get(hashmap, mapkey);
    if(retVal.val_base != NULL) {
        response_header_t response_header = {OK, retVal.val_len};
        Rio_writen(connfd, &response_header, sizeof(response_header));
        Rio_writen(connfd, retVal.val_base, retVal.val_len);
    }else {
        response_header_t response_header = {NOT_FOUND, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
    }
    free(key);
}

void handle_evict(int connfd, request_header_t request_header) {
    uint32_t key_size = request_header.key_size;
    if(key_size < MIN_KEY_SIZE || key_size > MAX_KEY_SIZE) {
        response_header_t response_header = {BAD_REQUEST, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
        return;
    }
    char *key = calloc(1, request_header.key_size);
    Rio_readn(connfd, key, request_header.key_size);
    map_key_t mapkey = {key, strlen(key)};
    map_node_t node =  delete(hashmap, mapkey);
    map_free_function(node.key, node.val);
    response_header_t response_header = {OK, 0};
    Rio_writen(connfd, &response_header, sizeof(response_header));
}

void handle_clear(int connfd){
    if(clear_map(hashmap) == true) {
        response_header_t response_header = {OK, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
    }else {
        response_header_t response_header = {BAD_REQUEST, 0};
        Rio_writen(connfd, &response_header, sizeof(response_header));
    }
}

