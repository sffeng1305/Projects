#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <readline/readline.h>
#include "sfish.h"
#include "debug.h"
#include "wait.h"
#include <signal.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
char* BUILTIN_HELP = "help";
char* BUILTIN_EXIT = "exit";
char* BUILTIN_CD = "cd";
char* BUILTIN_PWD = "pwd";
char* BUILTIN_CD_DOT = "cd .";
char* BUILTIN_CD_DOTDOT = "cd ..";
char* BUILTIN_CD_LINE = "cd -";
char* BUILTIN_JOBS = "jobs";
char* BUILTIN_FG = "fg";
char* BUILTIN_KILL = "kill";
int firstIndexOf(const char * str, const char toFind);
int lastIndexOf(const char * str, const char toFind);
int charOccurrences(char *str, char toFind);
char *trimStringSpaces(char *str);
void help();
void pwd();
void freeAllocatedJobs();
void fg_handle(char *input);
void kill_handle(char *input);


int shell_terminal;
int shell_pgid;
int status;
volatile sig_atomic_t pid;

struct Node
{
    int JID;
    int PID;
    char *jobName;
    struct Node *next;
};
struct Node* head = NULL;
void insert(struct Node** head, int JID, int PID, char *jobName);
void deleteNode(struct Node **head, int JID);
void printList(struct Node *head);
int getPID(struct Node **head, int JID);
int isContainPID(struct Node **head, int PID);
static void reverse(struct Node** head);
char *onejob;
int onejobcounter = 0;
int totalJID = 1;
void freeJOBs(char *onejob);
void freeJOBSList(struct Node **head);
char *getJobName(struct Node **head, int JID);

sigset_t mask;
sigset_t mask2, prev2;

void sigchld_handler(int s) {
    //int olderrno = errno;
    pid = waitpid(-1, &status, WUNTRACED | WCONTINUED); /* Main is waiting for nonzero pid */

    if (WIFSTOPPED(status)) {
        printf("\n");
        struct Node* tt = *(&head);
        if(tt == NULL) {
            totalJID = 1;
        }
        insert(&head, totalJID, pid, onejob);
        totalJID++;
    } else if(WIFSIGNALED(status)) {
        //printf("\n");
    } else if (WIFEXITED(status)) {
        //printf("exited, status=%d\n", WIFEXITED(status));
    } else if(WIFCONTINUED(status)) {
        tcsetpgrp(0, getpgid(pid));
        sigsuspend(&mask);
    }
    tcsetpgrp(0, shell_pgid);
    //errno = olderrno;sigset_t mask2, prev2;
}


int main(int argc, char *argv[], char* envp[]) {
    shell_terminal = STDIN_FILENO;
    shell_pgid = (int)getpgrp();
    tcsetpgrp(0, shell_pgid);


    signal(SIGCHLD, sigchld_handler);
    sigfillset(&mask);
    sigdelset(&mask, SIGCHLD);


    sigemptyset(&mask2);
    sigaddset(&mask2, SIGTSTP);
    sigaddset(&mask2, SIGINT);
    sigprocmask(SIG_BLOCK, &mask2, &prev2);

    signal(SIGTTOU, SIG_IGN);

    char* input;
    bool exited = false;

    if(!isatty(STDIN_FILENO)) {
        // If your shell is reading from a piped file
        // Don't have readline write anything to that file.
        // Such as the prompt or "user input"
        if((rl_outstream = fopen("/dev/null", "w")) == NULL){
            perror("Failed trying to open DEVNULL");
            exit(EXIT_FAILURE);
        }
    }

    char previousDirectory[80] = {0};
    char currentDirectory[80] = {0};
    char *homeDirectory = getenv("HOME");

    do {
        int checkIfTheFirstCD = 1;
        //setting the current directory
        getcwd(currentDirectory, 80);

        //setting promt
        char prompt[80], secondPart[80];
        strcpy(prompt, currentDirectory);
        strcpy(secondPart, " :: zhifchen >> ");

        char *finalPromt = prompt;
        if(strstr(prompt, homeDirectory) > 0) {
            finalPromt = finalPromt+strlen(homeDirectory)-1;
            *finalPromt = 126;
        }
        strcat(finalPromt, secondPart);
        input = readline(finalPromt);

        /*write(1, "\e[s", strlen("\e[s"));
        write(1, "\e[20;10H", strlen("\e[20;10H"));
        write(1, "SomeText", strlen("SomeText"));
        write(1, "\e[u", strlen("\e[u"));*/
        ///////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////
        //part 3
        //determine if it contains ">, < |", and trim unneccssary space.
        int lessThanSign = 60;//60 = <
        int greaterThanSign = 62;//62 = >
        int pileSign = 124;//124 = |
        int lessThanOccurrences = charOccurrences(input, 60);
        int greaterThanOccurrences = charOccurrences(input, 62);
        int pileOccurrences = charOccurrences(input, pileSign);

        if(lessThanOccurrences > 1  || greaterThanOccurrences > 1) {
            printf(SYNTAX_ERROR, input);
            goto jump;
        }

        if(pileOccurrences >= 1) {
            //parse the input into args
            int numOfElements = 0;
            char *totalArgs[100];
            char args[100];
            char *temp = args;
            char *remainingInput = input;
            int i = 0;
            for(i = 0; i < pileOccurrences; i++) {
                int index = firstIndexOf(remainingInput, pileSign);


                strncpy(temp, remainingInput, index);
                temp[index] = '\0';
                totalArgs[i] = temp;
                numOfElements++;
                temp = temp+index+1;
                remainingInput = remainingInput+index+1;

            }
            totalArgs[i] = remainingInput;
            numOfElements++;
            totalArgs[i+1] = NULL;

            for(int j = 0; j < numOfElements; j++) {
                if(strlen(totalArgs[j]) <= 1) {
                    printf(SYNTAX_ERROR, input);
                    goto jump;
                }

                char *temp = totalArgs[j];
                int k = 0;
                while(*temp != '\0') {
                    if(*temp == 32) {
                        k++;
                    }
                    temp++;
                }

                if(k == strlen(totalArgs[j])) {
                    printf(SYNTAX_ERROR, input);
                    goto jump;
                }
            }

            int *readCounter = (int*)malloc(sizeof(int));
            int *writeCounter = (int*)malloc(sizeof(int));
            int *commandc = (int*)malloc(sizeof(int));
            *readCounter = 0;
            *writeCounter = 1;
            *commandc = 0;


            pid = fork();
            if(pid < 0) {
                printf(EXEC_ERROR, "fork error");
                goto jump;
            }
            if(pid == 0) {
                int pipes[pileOccurrences*2];
                int status;
                for(int i = 0; i < pileOccurrences; i++) {
                    pipe(pipes+(i*2));
                }
                while(totalArgs[*commandc]){
                    pid = fork();
                    if(pid == 0) {
                        const char s[2] = " ";
                        char *token;
                        token = strtok(totalArgs[*commandc], s);
                        char *myArg[100];
                        int i = 0;
                        while(token != NULL) {
                            myArg[i] = token;
                            i++;
                            token = strtok(NULL, s);
                        }
                        myArg[i] = NULL;

                        if(*commandc == 0) {
                            int ret = dup2(pipes[*writeCounter], 1);
                            if(ret < 0) {
                                printf(EXEC_ERROR, "dup2 error");
                                exit(1);
                            }

                            for(int i = 0; i < pileOccurrences*2; i++) {
                                close(pipes[i]);
                            }
                            char *str = trimStringSpaces(myArg[0]);
                            if(strcmp(str, "help") == 0) {
                                help();
                            }else if(strcmp(str, "pwd") == 0) {
                                pwd();
                            }else {

                                int ret = execvp(myArg[0], myArg);
                                if(ret < 0) {
                                    fprintf(stderr,EXEC_NOT_FOUND, totalArgs[*commandc]);
                                }
                            }
                            _exit(0);
                        }else if(*commandc == (numOfElements-1)) {
                            int ret = dup2(pipes[*readCounter], 0);
                            if(ret < 0) {
                                printf(EXEC_ERROR, "dup2 error");
                                exit(1);
                            }
                            for(int i = 0; i < pileOccurrences*2; i++) {
                                close(pipes[i]);
                            }
                            char *str = trimStringSpaces(myArg[0]);
                            if(strcmp(str, "help") == 0) {
                                help();
                            }else if(strcmp(str, "pwd") == 0) {
                                pwd();
                            }else {

                                int ret = execvp(myArg[0], myArg);
                                if(ret < 0) {
                                    fprintf(stderr,EXEC_NOT_FOUND, totalArgs[*commandc]);
                                }
                            }
                            _exit(0);
                        }else {
                            int ret1 = dup2(pipes[*readCounter], 0);
                            int ret2 = dup2(pipes[*writeCounter], 1);
                            if(ret1 < 0 || ret2 < 0) {
                                printf(EXEC_ERROR, "dup2 error");
                                exit(1);
                            }
                            for(int i = 0; i < pileOccurrences*2; i++) {
                                close(pipes[i]);
                            }
                            char *str = trimStringSpaces(myArg[0]);
                            if(strcmp(str, "help") == 0) {
                                help();
                            }else if(strcmp(str, "pwd") == 0) {
                                pwd();
                            }else {
                                int ret = execvp(myArg[0], myArg);
                                if(ret < 0) {
                                    fprintf(stderr,EXEC_NOT_FOUND, totalArgs[*commandc]);
                                }
                            }
                            _exit(0);
                        }
                    }else {
                        if(*commandc == 0) {
                            *writeCounter = *writeCounter + 2;
                        }else {
                             //update counters
                            *writeCounter = *writeCounter + 2;
                            *readCounter = *readCounter + 2;
                        }
                        *commandc = *commandc+1;

                    }

                }

                //parent
                for(int i = 0; i < pileOccurrences*2; i++) {
                    close(pipes[i]);
                }
                for(i = 0; i < pileOccurrences; i++){
                    wait(&status);
                }
                _exit(0);
            }else {
                sigsuspend(&mask);

                free(readCounter);
                free(writeCounter);
                free(commandc);
                goto jump;
            }

        }

    //case 1
        if(lessThanOccurrences == 1 || greaterThanOccurrences == 1) {
            //check if it's second case.
            if(lessThanOccurrences == 1 && greaterThanOccurrences == 1){
                goto casetwo;
            }
            //get the requested argument.
            int index;
            if(lessThanOccurrences == 1) {
                index = lastIndexOf(input, lessThanSign);//indext of <
            }else if(greaterThanOccurrences == 1) {
                index = lastIndexOf(input, greaterThanSign);//indext of >
            }
            char temp[100];
            strncpy(temp, input, index);
            temp[index] = '\0';
            if(strcmp(temp, "") == 0) {
                printf(SYNTAX_ERROR, input);
                goto jump;
            }
            onejob = malloc(sizeof(char)*strlen(temp));
            onejobcounter++;
            strcpy(onejob, temp);
            const char s[2] = " ";
            char *token;
            token = strtok(temp, s);
            char *myArg[100];
            int i =0;
            while(token != NULL ) {
                myArg[i] = token;
                i++;
                token = strtok(NULL, s);
            }
            myArg[i] = NULL;
            //get the file name
            char fileName[50];
            strncpy(fileName, (input+index+1), strlen(input));
            int b = strlen(input)-index;
            fileName[b] = '\0';
            char *retFileName;
            retFileName = trimStringSpaces(fileName);
            if(strcmp(retFileName, "") == 0) {
                printf(SYNTAX_ERROR, input);
                goto jump;
            }

            pid = fork();
            if(pid < 0) {
                printf(EXEC_ERROR, "fork error");
                goto jump;
            }
            if(pid == 0) {/* Child */
                if(lessThanOccurrences == 1) {
                    int in = open(retFileName, O_RDONLY);
                    if(in < 0) {
                        printf("%s : No such file or directory\n", retFileName);
                        exit(1);
                    }
                    int ret = dup2(in, 0);
                    if(ret < 0) {
                        printf(EXEC_ERROR, "dup2 error");
                        exit(1);
                    }
                    close(in);
                }else if(greaterThanOccurrences == 1) {
                    int out = open(retFileName, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
                    int ret = dup2(out, 1);
                    if(ret < 0) {
                        printf(EXEC_ERROR, "dup2 error");
                        exit(1);
                    }
                    close(out);
                }
                char *str = trimStringSpaces(myArg[0]);
                if(strcmp(str, "help") == 0) {
                    help();
                }else if(strcmp(str, "pwd") == 0) {
                    pwd();
                }else {
                    int ret = execvp(myArg[0], myArg);
                    if(ret < 0) {
                        fprintf(stderr,EXEC_NOT_FOUND, temp);
                    }
                    exit(1);
                }
                exit(0);
            }
            /* Wait for SIGCHLD to be received */
            sigsuspend(&mask);

            goto jump;
        }

  casetwo:
        if(lessThanOccurrences == 1 && greaterThanOccurrences == 1){
            int lessThanIndex = lastIndexOf(input, lessThanSign);
            int greaterThanIndex = lastIndexOf(input, greaterThanSign);

            //get the requested argument.
            int index;
            if(lessThanIndex < greaterThanIndex) {
                index = lastIndexOf(input, lessThanSign);//indext of <
            }else if(greaterThanIndex < lessThanIndex) {
                index = lastIndexOf(input, greaterThanSign);//indext of >
            }
            char temp[100];
            strncpy(temp, input, index);
            temp[index] = '\0';
            if(strcmp(temp, "") == 0) {
                printf(SYNTAX_ERROR, input);
                goto jump;
            }
            onejob = malloc(sizeof(char)*strlen(temp));
            onejobcounter++;
            strcpy(onejob, temp);
            const char s[2] = " ";
            char *token;
            token = strtok(temp, s);
            char *myArg[100];
            int i =0;
            while(token != NULL ) {
                myArg[i] = token;
                i++;
                token = strtok(NULL, s);
            }
            myArg[i] = NULL;

            //get the file name 1
            char fileName[50];
            strncpy(fileName, (input+index+1), strlen(input));
            int b = strlen(input)-index;
            fileName[b] = '\0';
            char *retFileName1;
            retFileName1 = trimStringSpaces(fileName);
            if(strcmp(retFileName1, "") == 0) {
                printf(SYNTAX_ERROR, input);
                goto jump;
            }

            //get the file name 2
            char fileName2[50];
            if(lessThanIndex < greaterThanIndex) {
                strncpy(fileName2, (input+greaterThanIndex+1), strlen(input));
            }else if(greaterThanIndex < lessThanIndex) {
                strncpy(fileName2, (input+lessThanIndex+1), strlen(input));
            }
            int c = strlen(input)-index;
            fileName2[c] = '\0';
            char *retFileName2;
            retFileName2 = trimStringSpaces(fileName2);
            if(strcmp(retFileName2, "") == 0) {
                printf(SYNTAX_ERROR, input);
                goto jump;
            }

            pid = fork();
            if(pid == 0) {/* Child */
                if(lessThanIndex < greaterThanIndex) {
                    int in = open(retFileName1, O_RDONLY);
                    if(in < 0) {
                        printf("%s : No such file or directory\n", retFileName1);
                        exit(1);
                    }
                    int out = open(retFileName2, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
                    int ret1 = dup2(in, 0);
                    int ret2 = dup2(out, 1);
                    if(ret1 < 0 || ret2 < 0) {
                        printf(EXEC_ERROR, "dup2 error");
                        exit(1);
                    }
                    close(out);
                    close(in);
                }else if(greaterThanIndex < lessThanIndex) {
                    int in = open(retFileName2, O_RDONLY);
                    if(in < 0) {
                        printf("%s : No such file or directory\n", retFileName2);
                        exit(1);
                    }
                    int out = open(retFileName1, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
                    int ret1 = dup2(in, 0);
                    int ret2 = dup2(out, 1);
                    if(ret1 < 0 || ret2 < 0) {
                        printf(EXEC_ERROR, "dup2 error");
                        exit(1);
                    }
                    close(out);
                    close(in);
                }

                char *str = trimStringSpaces(myArg[0]);
                if(strcmp(str, "help") == 0) {
                    help();
                }else if(strcmp(str, "pwd") == 0) {
                    pwd();
                }else {
                    int ret = execvp(myArg[0], myArg);
                    if(ret < 0) {
                        fprintf(stderr,EXEC_NOT_FOUND, temp);
                    }
                }
                exit(0);
            }
            /* Wait for SIGCHLD to be received */
            sigsuspend(&mask);


            goto jump;
        }
        ///////BUILT IN///////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////
        //determine if it is cd command by getting the frist two chars.
        char l2_str[3];
        strncpy(l2_str, input,3);
        l2_str[3] = 0;
        strcpy(l2_str, trimStringSpaces(l2_str));

        char l4_str[5];
        strncpy(l4_str, input, 5);
        l4_str[5] = 0;
        strcpy(l4_str, trimStringSpaces(l4_str));
        /////////////////////////////////////////////////////
        if(strcmp(l4_str, BUILTIN_HELP) == 0) {
            help();
        }else if(strcmp(input, BUILTIN_EXIT) == 0){
            exited = 1;
        }else if(strcmp(l2_str, BUILTIN_CD) == 0) {
            if(strcmp(input, BUILTIN_CD) == 0) {
                chdir(homeDirectory);
            }else if(strcmp(input, BUILTIN_CD_LINE) == 0) {
                if(previousDirectory[0] == 0) {
                    checkIfTheFirstCD = 0;
                    printf("bash: cd: OLDPWD not set\n");
                }else {
                    printf("%s\n", previousDirectory);
                    chdir(previousDirectory);

                }

            }else if(strcmp(input, BUILTIN_CD_DOT) == 0) {
                chdir(currentDirectory);
            }else if(strcmp(input, BUILTIN_CD_DOTDOT) == 0) {
                int index = lastIndexOf(currentDirectory, '/');
                char parentDirectory[sizeof(currentDirectory)];
                strncpy(parentDirectory, currentDirectory, index);
                parentDirectory[index] = 0;
                chdir(parentDirectory);
            }else {
                char *path;
                path = strchr(input, ' ');
                path++;
                int spaceIndex = firstIndexOf(path, 32);
                if(spaceIndex == -1) {
                    int ret = chdir(path);
                    if(ret == -1) {
                        printf(BUILTIN_ERROR, input);
                    }
                }else {
                    printf(BUILTIN_ERROR, input);
                }
            }
             //setting the previous directory
            if(checkIfTheFirstCD != 0) {
                strcpy(previousDirectory, currentDirectory);
            }

        }else if(strcmp(input, BUILTIN_PWD) == 0) {
            pwd();
        }else if(strcmp(input, "") == 0){// If EOF is read (aka ^D) readline returns NULL
            continue;
        }else if(strcmp(l4_str, BUILTIN_JOBS) == 0) {
            printList(head);
        }else if(strcmp(l2_str, BUILTIN_FG) == 0){
            fg_handle(input);
        }else if(strcmp(l4_str, BUILTIN_KILL) == 0) {
            kill_handle(input);
        }else {
            //part 2///////////////////////////////////////////////////
            char temp[100];
            strcpy(temp, input);
            const char s[2] = " ";
            char *token;
            token = strtok(temp, s);
            char *myArg[100];
            int i =0;
            while(token != NULL ) {
                myArg[i] = token;
                i++;
                token = strtok(NULL, s);
            }
            myArg[i] = NULL;

            onejob = malloc(sizeof(char)*strlen(input));
            onejobcounter++;
            strcpy(onejob, input);

            int ret = 1;
            pid = fork();
            if(pid < 0) {
                printf(EXEC_ERROR, "fork error");
                goto jump;
            }

            if(pid == 0) {/* Child */
                sigprocmask(SIG_SETMASK, &prev2, NULL);//unblock SIGTSTP SIGINT
                setpgid(0, getpid());
                ret = execvp(myArg[0], myArg);
                if(ret < 0) {
                    printf(EXEC_NOT_FOUND, input);
                }
                free(onejob);
                exit(0);
            }
            setpgid(pid, pid);
            tcsetpgrp(0, pid);
            /* Wait for SIGCHLD to be received */
            sigsuspend(&mask);
        }
jump:
        // Readline mallocs the space for input. You must free it.
        rl_free(input);
    } while(!exited);
    debug("%s", "user entered 'exit'");
    freeJOBSList(&head);
    return EXIT_SUCCESS;
}


void kill_handle(char *input) {
    int percentSignOccurence = charOccurrences(input, '%');
    if(percentSignOccurence == 1) {
        int pSIndex = firstIndexOf(input, '%');
        char *temp = input+pSIndex+1;
        int spaceIndex = firstIndexOf(temp, 32);
        if(spaceIndex != -1) {
            *(temp+spaceIndex) = '\0';
        }

        int jidNumber = atoi(temp);
        if(jidNumber == 0) {
            printf(BUILTIN_ERROR, input);
            return;
        }

        int pidNumber = getPID(&head, jidNumber);
        if(pidNumber < 0) {
            printf(BUILTIN_ERROR, input);
            return;
        }

        tcsetpgrp(0, pidNumber);
        kill(pidNumber, SIGKILL);
        deleteNode(&head, jidNumber);
        totalJID--;
        sigsuspend(&mask);
    }else if(percentSignOccurence == -1) {
        int spaceIndex = firstIndexOf(input, 32);
        char *temp = input+spaceIndex+1;
        int pidNumber = atoi(temp);
        if(pidNumber == 0) {
            printf(BUILTIN_ERROR, input);
            return;
        }

        int jidNumber = isContainPID(&head, pidNumber);
        if(jidNumber < 0) {
            printf(BUILTIN_ERROR, input);
            return;
        }

        tcsetpgrp(0, pidNumber);
        kill(pidNumber, SIGKILL);
        deleteNode(&head, jidNumber);
        totalJID--;
        sigsuspend(&mask);
    }
}


void fg_handle(char *input) {
    int percentSignOccurence = charOccurrences(input, '%');

    if(percentSignOccurence == 1) {
        int pSIndex = firstIndexOf(input, '%');
        char *temp = input+pSIndex+1;
        int jidNumber = atoi(temp);
        if(jidNumber == 0) {
            printf(BUILTIN_ERROR, input);
            return;
        }

        int pidNumber = getPID(&head, jidNumber);
        onejob = getJobName(&head, jidNumber);
        if(pidNumber < 0) {
            printf(BUILTIN_ERROR, input);
            return;
        }

        tcsetpgrp(0, pidNumber);
        kill(pidNumber, SIGCONT);
        deleteNode(&head, jidNumber);
        sigsuspend(&mask);

        struct Node* tt = *(&head);
        if(tt == NULL) {
            totalJID = 1;
        }
    }
}


void printList(struct Node *head){
    reverse(&head);
    struct Node *temp = head;
    while (temp != NULL){
        printf(JOBS_LIST_ITEM, temp->JID, temp->jobName);
        temp = temp->next;
    }
    reverse(&head);
}

void help() {
    fprintf(stdout,"  'help'    : Print a list of all builtins and their basic usage in a single column.\n");
    fprintf(stdout,"  'exit'    : Exits the shell.\n");
    fprintf(stdout,"  'cd'      :With no argument, Go to the user's home directory.\n");
    fprintf(stdout,"  'cd'      :With argument, Go to the specified path.\n");
    fprintf(stdout,"  'cd -'    : Change the working directory to the last directory the user was in.\n");
    fprintf(stdout,"  'cd .'    : Change to the current directory\n");
    fprintf(stdout,"  'cd ..'   : Change to the previous directory\n");
    fprintf(stdout,"  'pwd'     : Prints the absolute path of the current working directory.\n");
}

void pwd() {
    char str[80];
    getcwd(str, 80);
    fprintf(stdout, "%s\n", str);
}

int firstIndexOf(const char * str, const char toFind) {
    int index = -1;
    int i = 0;
    while(str[i] != '\0'){
        if(str[i] == toFind){
            index = i;
            break;
        }
        i++;
    }
    return index;
}


int lastIndexOf(const char * str, const char toFind){
    int index = -1;
    int i = 0;
    while(str[i] != '\0'){
        if(str[i] == toFind){
            index = i;
        }
        i++;
    }
    return index;
}


int charOccurrences(char *str, char toFind) {
    int occurrence = 0;
    int i = 0;
    while(str[i] != '\0'){
        if(str[i] == toFind){
           occurrence++;
        }
        i++;
    }
    if(occurrence > 0) {
        return occurrence;
    }
    return -1;
}

char *trimStringSpaces(char *str) {//cut the spaces begin and end at the string.
    char* ret;
    int i = 0;
    while(str[i] == 32) {
        i++;
    }

    ret = str+i;
    int j = 0;
    while(ret[j] != 32) {
        if(ret[j] == '\0') {
            break;
        }
        j++;
    }
    if(ret[j] == 32) {
        ret[j] = '\0';
    }

    return ret;
}

void insert(struct Node** head, int JID, int PID, char *jobName){
    struct Node* new_node = (struct Node*) malloc(sizeof(struct Node));
    new_node->JID = JID;
    new_node->PID = PID;
    new_node->jobName = jobName;
    new_node->next = (*head);
    (*head) = new_node;
}

void deleteNode(struct Node **head, int JID){
    struct Node* temp = *head, *prev;
    if (temp != NULL && temp->JID == JID){
        *head = temp->next;
        free(temp);
        //free(temp->jobName);
        return;
    }
    while (temp != NULL && temp->JID != JID){
        prev = temp;
        temp = temp->next;
    }
    if(temp == NULL) {
        return;
    }
    prev->next = temp->next;
    free(temp);
    //free(temp->jobName);
}

int getPID(struct Node **head, int JID) {
    struct Node* temp = *head;
    while (temp != NULL){

        if(temp->JID == JID) {
            return temp->PID;
        }
        temp = temp->next;
    }
    return -1;
}

char *getJobName(struct Node **head, int JID) {
    struct Node* temp = *head;
    while (temp != NULL){

        if(temp->JID == JID) {
            return temp->jobName;
        }
        temp = temp->next;
    }
    return NULL;
}

int isContainPID(struct Node **head, int PID) {
    struct Node* temp = *head;
    while (temp != NULL){

        if(temp->PID == PID) {
            return temp->JID;
        }
        temp = temp->next;
    }
    return -1;
}

static void reverse(struct Node** head){
    struct Node* prev   = NULL;
    struct Node* current = *head;
    struct Node* next;
    while (current != NULL){
        next  = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    *head = prev;
}

void freeJOBSList(struct Node **head) {
    struct Node* temp = *head;
    while (temp != NULL){
        free(temp->jobName);
        free(temp);
        temp = temp->next;
    }
}

