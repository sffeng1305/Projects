package buzzword;

/**
 * Created by Archi on 11/8/16.
 */
public enum BuzzwordProperties {
    HEADING_LABEL,

    //MODE NAME
    ANIMALS,
    SPORTS,
    RESTAURANT,

}
